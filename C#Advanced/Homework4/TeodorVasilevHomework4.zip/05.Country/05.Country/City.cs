﻿namespace _05.Country
{
    public class City
    {
        public City(string name)
        {
            this.Name = name;
        }

        public string Name { get; set; }
    }
}
