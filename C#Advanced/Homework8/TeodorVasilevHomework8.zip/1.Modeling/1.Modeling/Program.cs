﻿using _1.Modeling;

var factory = new SchoolFactory();
var school = factory.Create();