﻿namespace _1.Modeling
{
    public class Grade
    {
        public string Course { get; set; }
        public double Rating { get; set; }
    }
}
