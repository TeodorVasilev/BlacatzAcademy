﻿namespace _2._Chefs
{
    public class MasterChef : Chef
    {
        public MasterChef(string name) : base(name)
        {
            this.YearsExperience = 10;
        }
    }
}
