﻿namespace _2._Chefs
{
    public class NewbieChef : Chef
    {
        public NewbieChef(string name) : base(name)
        {
            this.YearsExperience = 0;
        }
    }
}
