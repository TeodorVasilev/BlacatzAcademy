﻿namespace _3._Bank
{
    public enum Role
    {
        Banker,
        LoanProcessor,
        InvestmentAnalyst,
        CreditAnalyst
    }
}
