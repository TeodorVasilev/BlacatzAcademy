﻿namespace _1._IDevice
{
    public interface IDevice
    {
        string Ram { get; set; }
        string Processor { get; set; }
    }
}
