﻿namespace _1._IDevice
{
    public class Phone : IDevice
    {
        public string Ram { get; set; }
        public string Processor { get; set; }
    }
}
