﻿namespace _1._IDevice
{
    public class Computer : IDevice
    {
        public string Ram { get; set; }
        public string Processor { get; set; }
    }
}
