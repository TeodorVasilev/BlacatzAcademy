﻿namespace _2.Struct
{
    public class Website : IWebsite
    {
        public string Title { get; set; }
        public string Address { get; set; }
    }
}
