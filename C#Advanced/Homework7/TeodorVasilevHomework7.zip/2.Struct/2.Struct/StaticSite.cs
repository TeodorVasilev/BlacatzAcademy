﻿namespace _2.Struct
{
    public class StaticSite : InformationSite
    {
    }
}
