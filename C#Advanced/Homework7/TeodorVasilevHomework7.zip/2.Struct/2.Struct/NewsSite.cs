﻿namespace _2.Struct
{
    public class NewsSite : InformationSite
    {
    }
}
