﻿namespace _2.Struct
{
    public interface IOnlineStore
    {
        List<object> Objects { get; set; }
    }
}
