﻿namespace _2.Struct
{
    public class BasicOnlineStore : OnlineStore
    {
    }
}
