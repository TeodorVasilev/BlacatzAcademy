﻿namespace _2.Struct
{
    public interface IInformationSite
    {
        string Information { get; set; }
    }
}
