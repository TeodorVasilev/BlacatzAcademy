﻿namespace _2.Struct
{
    public class InformationSite : Website, IInformationSite
    {
        public string Information { get; set; }
    }
}
