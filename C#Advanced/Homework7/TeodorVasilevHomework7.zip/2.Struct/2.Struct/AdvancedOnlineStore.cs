﻿namespace _2.Struct
{
    public class AdvancedOnlineStore : OnlineStore
    {
    }
}
