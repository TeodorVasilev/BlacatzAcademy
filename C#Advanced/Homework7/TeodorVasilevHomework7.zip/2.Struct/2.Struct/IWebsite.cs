﻿namespace _2.Struct
{
    public interface IWebsite
    {
        string Title { get; set; }
        string Address { get; set; }
    }
}
